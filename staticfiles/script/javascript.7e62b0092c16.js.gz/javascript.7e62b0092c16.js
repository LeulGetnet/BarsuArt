  function changeImage(imageSrc) {
    const mainImage = document.getElementById('activeImage');
    mainImage.src = imageSrc;
  }